/* ==========================================================================
   TUNÇ DİJİTAL — script.js
   Vanilla JavaScript. No dependencies.
   ========================================================================== */

(function () {
  "use strict";

  /* ------------------------------------------------------------------------
     1. Sticky header background on scroll
     ------------------------------------------------------------------------ */
  const header = document.getElementById("siteHeader");

  function updateHeaderState() {
    if (window.scrollY > 12) {
      header.classList.add("is-scrolled");
    } else {
      header.classList.remove("is-scrolled");
    }
  }
  updateHeaderState();
  window.addEventListener("scroll", updateHeaderState, { passive: true });

  /* ------------------------------------------------------------------------
     2. Mobile navigation toggle
     ------------------------------------------------------------------------ */
  const navToggle = document.getElementById("navToggle");
  const mainNav = document.getElementById("mainNav");

  function closeNav() {
    mainNav.classList.remove("is-open");
    navToggle.setAttribute("aria-expanded", "false");
    navToggle.setAttribute("aria-label", "Menüyü aç");
  }

  function toggleNav() {
    const isOpen = mainNav.classList.toggle("is-open");
    navToggle.setAttribute("aria-expanded", String(isOpen));
    navToggle.setAttribute("aria-label", isOpen ? "Menüyü kapat" : "Menüyü aç");
  }

  navToggle.addEventListener("click", toggleNav);

  mainNav.querySelectorAll("a").forEach(function (link) {
    link.addEventListener("click", closeNav);
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeNav();
  });

  /* ------------------------------------------------------------------------
     3. Scroll reveal (IntersectionObserver)
     ------------------------------------------------------------------------ */
  const revealEls = document.querySelectorAll(".reveal, .reveal-stagger");

  if ("IntersectionObserver" in window && revealEls.length) {
    const revealObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            revealObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -60px 0px" }
    );

    revealEls.forEach(function (el) {
      revealObserver.observe(el);
    });
  } else {
    // Fallback: no IO support — show everything immediately
    revealEls.forEach(function (el) {
      el.classList.add("is-visible");
    });
  }

  /* ------------------------------------------------------------------------
     4. FAQ accordion
     ------------------------------------------------------------------------ */
  const faqItems = document.querySelectorAll(".faq-item");

  faqItems.forEach(function (item) {
    const q = item.querySelector(".faq-q");
    const a = item.querySelector(".faq-a");
    const inner = item.querySelector(".faq-a-inner");

    q.addEventListener("click", function () {
      const isOpen = item.getAttribute("data-open") === "true";

      // Close all other items (single-open accordion)
      faqItems.forEach(function (other) {
        if (other !== item) {
          other.setAttribute("data-open", "false");
          other.querySelector(".faq-q").setAttribute("aria-expanded", "false");
          other.querySelector(".faq-a").style.maxHeight = null;
        }
      });

      if (isOpen) {
        item.setAttribute("data-open", "false");
        q.setAttribute("aria-expanded", "false");
        a.style.maxHeight = null;
      } else {
        item.setAttribute("data-open", "true");
        q.setAttribute("aria-expanded", "true");
        a.style.maxHeight = inner.scrollHeight + 24 + "px";
      }
    });
  });

  /* ------------------------------------------------------------------------
     5. Contact form -> WhatsApp handoff
     ------------------------------------------------------------------------ */
  const contactForm = document.getElementById("contactForm");
  const WHATSAPP_PHONE = "905302875826";

  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const name = contactForm.name.value.trim();
      const phone = contactForm.phone.value.trim();
      const sector = contactForm.sector.value;
      const message = contactForm.message.value.trim();

      if (!name || !phone) {
        contactForm.reportValidity();
        return;
      }

      let text = "Merhaba, Tunç Dijital web sitesinden yazıyorum.\n";
      text += "Ad Soyad: " + name + "\n";
      text += "Telefon: " + phone + "\n";
      if (sector) text += "Sektör: " + sector + "\n";
      if (message) text += "Mesaj: " + message;

      const url =
        "https://api.whatsapp.com/send/?phone=" +
        WHATSAPP_PHONE +
        "&text=" +
        encodeURIComponent(text) +
        "&type=phone_number&app_absent=0";

      window.open(url, "_blank", "noopener");
    });
  }

  /* ------------------------------------------------------------------------
     6. Footer year
     ------------------------------------------------------------------------ */
  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

})();
